// >>>>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<
// ------------------------------------------------------------------
// Copyright (c) 2019-2025 by Lattice Semiconductor Corporation
// ALL RIGHTS RESERVED
// ------------------------------------------------------------------
//
// MachXO4 Eval board example LFMXO4-110-EVN
// Lab 3 : RiscV + 7 Segments + Oled2
// Check github for reference
//
// Author : Jay V
// Date : April 2026
//
// Purpose: Tutorial / Demonstration
//
// Information : https://www.latticesemi.com/en/Products/DevelopmentBoardsAndKits/MachXO4-Development-Board
//
// File: Main.c
//
// Writes Lattice Logo to Display, loops text around
// Used display: WaveShare 1.5" RGb oled module 128x128 pixels
// Reference : https://www.waveshare.com/wiki/1.5inch_RGB_OLED_Module#Documentation
// Used display Driver : SSD1351
// ------------------------------------------------------------------

#include "hal.h"
#include "utils.h"
#include <stdio.h>
#include "sys_platform.h"
#include <riscv_errors.h>
#include "platform_init.h"
#include "device_info.h"
#include "terminal.h"
#include "seg7.h"		//added
#include "ssd1351.h"	// added
#include "font_4bpp.h"	// added

#if REG_TEST_ENABLE
#include "reg_test.h"
#endif

#ifdef LED_GPIO_INST_BASE_ADDR
#include "gpio.h"
#define LED_COUNT 8
struct gpio_instance led_gpio_inst;
#else
#define LED_COUNT 8
#endif

static int bsp_init(void)
{
	int ret = 0;

	ret = terminal_init(IRQ_BAREMETAL_DEFAULT);

#if CPU_INST_0_PIC_ENABLE
	//initialize PIC. for MC/SM/NANO
	pic_init(CPU_INST_0_PICTIMER_START_ADDR);
#endif

#if CPU_INST_0_PLIC_EN
	//initialize PLIC. for RX
	plic_init();
#endif

#if CPU_INST_0_PLIC_EN || CPU_INST_0_CLINT_EN
	trap_init();
#endif

#if REG_TEST_ENABLE
	/* Used for register access test, If not sure how to use, disable it. */
	reg_test_assert(mem_access_test());
	//printf("\nmem_access_test success!\n\n");
#endif

#ifdef LED_GPIO_INST_BASE_ADDR
	//initialize LED GPIO
	led_gpio_inst.instance_name = LED_GPIO_INST_NAME;
	gpio_init(&led_gpio_inst, LED_GPIO_INST_BASE_ADDR, LED_GPIO_INST_LINES_NUM, LED_GPIO_INST_GPIO_DIRS);
#endif


#ifdef OLED0_INST_BASE_ADDR
	// init oled
	base_ssd1351(OLED0_INST_BASE_ADDR); 		// set base address spi
	init_ssd1351();								// init oled via spi, 65K RGB565
	set_orientation_ssd1351(ORIENTATION_1);
	//draw_testpattern();
	draw_lattice_ssd1351(36,18,12);				// draw lattice logo in rectangles
	//printf("SPI-Oled setup : ID[0x%08X]\n",readSPIMemory_ssd1351(ID_REGISTER));

#endif

#ifdef SEG70_INST_BASE_ADDR
	//initialize Seg7
	seg7_init(SEG70_INST_BASE_ADDR);
	seg7_senddata(SEG_X);delay(100);
	seg7_senddata(SEG_O);delay(100);
	seg7_senddata(SEG_4);delay(100);

#endif



#ifdef RISCV_RX_DRV_VER
	/*If driver support, set global interrupt-enable bit to 1.*/
#if CPU_INST_0_PLIC_EN || CPU_INST_0_CLINT_EN
	plic_enable_global_interrupts(1);
#endif
#endif
	return ret;
}


int main(void) {
	static uint8_t idx = 0, idy=0;
	static uint8_t pin_state = 0xFF;
	static uint8_t loop[8] ={SEG_A,SEG_G,SEG_D,SEG_G,SEG_A,SEG_G,SEG_D,SEG_G};

	bsp_init();

	draw_text_ssd1351( " Welcome ", ArialRND12p, 12, 86,WHITE,BLACK);
	draw_text_ssd1351( "RISC-V ", ArialRND12p, 76, 86,GOLD,BLACK);

	while (true) {
#ifdef LED_GPIO_INST_BASE_ADDR
		gpio_output_write(&led_gpio_inst, idx, pin_state);
		seg7_senddata(loop[idx]);
#endif

#ifdef OLED0_INST_BASE_ADDR
		draw_text_ssd1351( " XO4 Rules ", ArialRND12p, 4*idy, 115,DARKGRAY,GOLD);
		idy = (idy+1)%33;

		// bit of fun
		if (idy==30 ) {
			draw_rectangle_ssd1351(45,27,LOGO_L_WIDTH+4,LOGO_L_HEIGHT+4,BLACK);
			draw_image_ssd1351(47,29, LOGO_L_WIDTH, LOGO_L_HEIGHT,logo_1);
			}
		if (idy == 1) {
			draw_lattice_ssd1351(36,18,12);
			}

#endif

		if (++idx == LED_COUNT) {
			idx = 0;
			pin_state = ~pin_state;
		}

		if (RTL_SIM) {
			delay(1);
		} else {
			//delay(2);
		}
	}

	return 0;
}

