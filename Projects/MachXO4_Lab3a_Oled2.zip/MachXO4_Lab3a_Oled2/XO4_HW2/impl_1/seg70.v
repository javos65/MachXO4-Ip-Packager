// Verilog netlist produced by program LSE 
// Netlist written on Sat Apr 25 19:27:08 2026
// Source file index table: 
// Object locations will have the form @<file_index>(<first_ line>[<left_column>],<last_line>[<right_column>])
// file 0 "c:/lscc/radiant/2025.2/ip/lfmxo4/ram_dp/rtl/lscc_lfmxo4_ram_dp.v"
// file 1 "c:/lscc/radiant/2025.2/ip/lfmxo4/ram_dp_true/rtl/lscc_lfmxo4_ram_dp_true.v"
// file 2 "c:/lscc/radiant/2025.2/ip/lfmxo4/ram_dq/rtl/lscc_lfmxo4_ram_dq.v"
// file 3 "c:/lscc/radiant/2025.2/ip/common/adder/rtl/lscc_adder.v"
// file 4 "c:/lscc/radiant/2025.2/ip/common/adder_subtractor/rtl/lscc_add_sub.v"
// file 5 "c:/lscc/radiant/2025.2/ip/common/complex_mult/rtl/lscc_complex_mult.v"
// file 6 "c:/lscc/radiant/2025.2/ip/common/counter/rtl/lscc_cntr.v"
// file 7 "c:/lscc/radiant/2025.2/ip/common/distributed_dpram/rtl/lscc_distributed_dpram.v"
// file 8 "c:/lscc/radiant/2025.2/ip/common/distributed_rom/rtl/lscc_distributed_rom.v"
// file 9 "c:/lscc/radiant/2025.2/ip/common/distributed_spram/rtl/lscc_distributed_spram.v"
// file 10 "c:/lscc/radiant/2025.2/ip/common/fifo_dc/rtl/lscc_fifo_dc.v"
// file 11 "c:/lscc/radiant/2025.2/ip/common/mult_accumulate/rtl/lscc_mult_accumulate.v"
// file 12 "c:/lscc/radiant/2025.2/ip/common/mult_add_sub/rtl/lscc_mult_add_sub.v"
// file 13 "c:/lscc/radiant/2025.2/ip/common/mult_add_sub_sum/rtl/lscc_mult_add_sub_sum.v"
// file 14 "c:/lscc/radiant/2025.2/ip/common/multiplier/rtl/lscc_multiplier.v"
// file 15 "c:/lscc/radiant/2025.2/ip/common/ram_dp/rtl/lscc_ram_dp.v"
// file 16 "c:/lscc/radiant/2025.2/ip/common/ram_dp_true/rtl/lscc_ram_dp_true.v"
// file 17 "c:/lscc/radiant/2025.2/ip/common/ram_dq/rtl/lscc_ram_dq.v"
// file 18 "c:/lscc/radiant/2025.2/ip/common/ram_shift_reg/rtl/lscc_shift_register.v"
// file 19 "c:/lscc/radiant/2025.2/ip/common/rom/rtl/lscc_rom.v"
// file 20 "c:/lscc/radiant/2025.2/ip/common/subtractor/rtl/lscc_subtractor.v"
// file 21 "c:/lscc/radiant/2025.2/ip/pmi/pmi_add.v"
// file 22 "c:/lscc/radiant/2025.2/ip/pmi/pmi_addsub.v"
// file 23 "c:/lscc/radiant/2025.2/ip/pmi/pmi_complex_mult.v"
// file 24 "c:/lscc/radiant/2025.2/ip/pmi/pmi_counter.v"
// file 25 "c:/lscc/radiant/2025.2/ip/pmi/pmi_distributed_dpram.v"
// file 26 "c:/lscc/radiant/2025.2/ip/pmi/pmi_distributed_rom.v"
// file 27 "c:/lscc/radiant/2025.2/ip/pmi/pmi_distributed_shift_reg.v"
// file 28 "c:/lscc/radiant/2025.2/ip/pmi/pmi_distributed_spram.v"
// file 29 "c:/lscc/radiant/2025.2/ip/pmi/pmi_fifo_dc.v"
// file 30 "c:/lscc/radiant/2025.2/ip/pmi/pmi_mac.v"
// file 31 "c:/lscc/radiant/2025.2/ip/pmi/pmi_mult.v"
// file 32 "c:/lscc/radiant/2025.2/ip/pmi/pmi_multaddsub.v"
// file 33 "c:/lscc/radiant/2025.2/ip/pmi/pmi_multaddsubsum.v"
// file 34 "c:/lscc/radiant/2025.2/ip/pmi/pmi_ram_dp.v"
// file 35 "c:/lscc/radiant/2025.2/ip/pmi/pmi_ram_dp_be.v"
// file 36 "c:/lscc/radiant/2025.2/ip/pmi/pmi_ram_dp_true.v"
// file 37 "c:/lscc/radiant/2025.2/ip/pmi/pmi_ram_dq.v"
// file 38 "c:/lscc/radiant/2025.2/ip/pmi/pmi_ram_dq_be.v"
// file 39 "c:/lscc/radiant/2025.2/ip/pmi/pmi_rom.v"
// file 40 "c:/lscc/radiant/2025.2/ip/pmi/pmi_sub.v"
// file 41 "c:/lscc/radiant/2025.2/cae_library/simulation/verilog/lfmxo4/eclksyncb.v"
// file 42 "c:/lscc/radiant/2025.2/cae_library/simulation/verilog/lfmxo4/gsrb.v"
// file 43 "c:/lscc/radiant/2025.2/cae_library/simulation/verilog/lfmxo4/pllrefcsb.v"
// file 44 "c:/lscc/radiant/2025.2/cae_library/simulation/verilog/lfmxo4/sgsra.v"
// file 45 "c:/lscc/radiant/2025.2/cae_library/simulation/verilog/xoplatform/dccb.v"
// file 46 "c:/lscc/radiant/2025.2/cae_library/simulation/verilog/xoplatform/l6mux21.v"
// file 47 "c:/lscc/radiant/2025.2/cae_library/simulation/verilog/xoplatform/mux161.v"
// file 48 "c:/lscc/radiant/2025.2/cae_library/simulation/verilog/xoplatform/mux21.v"
// file 49 "c:/lscc/radiant/2025.2/cae_library/simulation/verilog/xoplatform/mux321.v"
// file 50 "c:/lscc/radiant/2025.2/cae_library/simulation/verilog/xoplatform/mux41.v"
// file 51 "c:/lscc/radiant/2025.2/cae_library/simulation/verilog/xoplatform/mux81.v"
// file 52 "c:/lscc/radiant/2025.2/cae_library/simulation/verilog/xoplatform/io_specialprim.v"
// file 53 "c:/workspace/machxo4_lab3a_oled2/xo4_hw2/reginit.bin"

//
// Verilog Description of module seg70
// module wrapper written out since it is a black-box. 
//

//

module seg70 (PCLK, RST_N, PADDR, PSEL, PENABLE, PWRITE, PWDATA, 
            PRDATA, PREADY, PSLVERR, SEG7_OUT) /* synthesis ORIG_MODULE_NAME="seg70", LATTICE_IP_GENERATED="1", cpe_box=1 */ ;
    input PCLK;
    input RST_N;
    input [3:0]PADDR;
    input PSEL;
    input PENABLE;
    input PWRITE;
    input [31:0]PWDATA;
    output [31:0]PRDATA;
    output PREADY;
    output PSLVERR;
    output [7:0]SEG7_OUT;
    
    
    
endmodule
