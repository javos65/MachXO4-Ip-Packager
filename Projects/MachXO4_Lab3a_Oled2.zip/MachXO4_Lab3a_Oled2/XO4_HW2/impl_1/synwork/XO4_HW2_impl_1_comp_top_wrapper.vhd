--
-- Synopsys
-- Vhdl wrapper for top level design, written on Sat Apr 25 19:28:00 2026
--
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity wrapper_for_apb_to_spi is
   port (
      clk_i : in std_logic;
      rst_n_i : in std_logic;
      sclk_i : in std_logic;
      PSEL : in std_logic;
      PENABLE : in std_logic;
      PADDR : in std_logic_vector(7 downto 0);
      PWRITE : in std_logic;
      PWDATA : in std_logic_vector(31 downto 0);
      PRDATA : out std_logic_vector(31 downto 0);
      PREADY : out std_logic;
      PSLVERR : out std_logic;
      SCLK : out std_logic;
      DC : out std_logic;
      CS : out std_logic;
      SDIN : out std_logic;
      RST : out std_logic
   );
end wrapper_for_apb_to_spi;

architecture rtl_apb_to_spi of wrapper_for_apb_to_spi is

component apb_to_spi
 port (
   clk_i : in std_logic;
   rst_n_i : in std_logic;
   sclk_i : in std_logic;
   PSEL : in std_logic;
   PENABLE : in std_logic;
   PADDR : in std_logic_vector (7 downto 0);
   PWRITE : in std_logic;
   PWDATA : in std_logic_vector (31 downto 0);
   PRDATA : out std_logic_vector (31 downto 0);
   PREADY : out std_logic;
   PSLVERR : out std_logic;
   SCLK : out std_logic;
   DC : out std_logic;
   CS : out std_logic;
   SDIN : out std_logic;
   RST : out std_logic
 );
end component;

signal tmp_clk_i : std_logic;
signal tmp_rst_n_i : std_logic;
signal tmp_sclk_i : std_logic;
signal tmp_PSEL : std_logic;
signal tmp_PENABLE : std_logic;
signal tmp_PADDR : std_logic_vector (7 downto 0);
signal tmp_PWRITE : std_logic;
signal tmp_PWDATA : std_logic_vector (31 downto 0);
signal tmp_PRDATA : std_logic_vector (31 downto 0);
signal tmp_PREADY : std_logic;
signal tmp_PSLVERR : std_logic;
signal tmp_SCLK : std_logic;
signal tmp_DC : std_logic;
signal tmp_CS : std_logic;
signal tmp_SDIN : std_logic;
signal tmp_RST : std_logic;

begin

tmp_clk_i <= clk_i;

tmp_rst_n_i <= rst_n_i;

tmp_sclk_i <= sclk_i;

tmp_PSEL <= PSEL;

tmp_PENABLE <= PENABLE;

tmp_PADDR <= PADDR;

tmp_PWRITE <= PWRITE;

tmp_PWDATA <= PWDATA;

PRDATA <= tmp_PRDATA;

PREADY <= tmp_PREADY;

PSLVERR <= tmp_PSLVERR;

SCLK <= tmp_SCLK;

DC <= tmp_DC;

CS <= tmp_CS;

SDIN <= tmp_SDIN;

RST <= tmp_RST;



u1:   apb_to_spi port map (
		clk_i => tmp_clk_i,
		rst_n_i => tmp_rst_n_i,
		sclk_i => tmp_sclk_i,
		PSEL => tmp_PSEL,
		PENABLE => tmp_PENABLE,
		PADDR => tmp_PADDR,
		PWRITE => tmp_PWRITE,
		PWDATA => tmp_PWDATA,
		PRDATA => tmp_PRDATA,
		PREADY => tmp_PREADY,
		PSLVERR => tmp_PSLVERR,
		SCLK => tmp_SCLK,
		DC => tmp_DC,
		CS => tmp_CS,
		SDIN => tmp_SDIN,
		RST => tmp_RST
       );
end rtl_apb_to_spi;
