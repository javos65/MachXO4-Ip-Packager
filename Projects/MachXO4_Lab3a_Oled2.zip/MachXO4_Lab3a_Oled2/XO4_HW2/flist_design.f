## Radiant Files
XO4_HW2/XO4_HW2.v
XO4_HW2/lib/latticesemi.com/ip/cpu0/1.8.0/cpu0.ipx
XO4_HW2/lib/latticesemi.com/module/pll0/3.0.1/pll0.ipx
XO4_HW2/lib/latticesemi.com/module/osc0/1.1.0/osc0.ipx
XO4_HW2/lib/latticesemi.com/module/ahbl2apb0/1.2.0/ahbl2apb0.ipx
XO4_HW2/lib/latticesemi.com/module/apb0/1.4.0/apb0.ipx
XO4_HW2/lib/latticesemi.com/ip/system0/2.5.1/system0.ipx
XO4_HW2/lib/JVos/ip/seg70/2.0.4/seg70.ipx
XO4_HW2/lib/latticesemi.com/module/ahbl0/1.5.0/ahbl0.ipx
XO4_HW2/lib/JVos/ip/oled0/3.0.5/oled0.ipx
XO4_HW2/lib/latticesemi.com/ip/gpio0/1.8.0/gpio0.ipx
