
# $propelRegenLsccBase: Propel installation path, e.g. C:/lscc/propel/2023.2
# If there is any file configuration in sbp_config_ip command, need to update the file path to the correct path on local setup, such as INIT_FILE in IP "System Memory".
# If there is any file configuration in sbp_add_gluelogic command, need to update the file path to the correct path on local setup, such as filepath and auto_soc option.

set targetDir "C:/workspace/MachXO4_Lab2"
set projectName "ASC_HW"


if {[info exists ::env(GenTclProjDir)]} {
    set targetDir $env(GenTclProjDir)
}

if {[info exists ::env(GenTclProjName)]} {
    set projectName $env(GenTclProjName)
}
 


if {[file exists "$targetDir"] != 1} {
    puts "$targetDir doesn't exist. Please update this setting in tcl file first."
    return
}



sbp_create_project  -name "$projectName" -path "$targetDir" -device {LFMXO4-110HC-5BBG484C}  -speed {5} -language {verilog} -board {NA} 

sbp_design save

sbp_delete "$projectName/clk_i" -type port
sbp_delete "$projectName/rstn_i" -type port



try {

proc is_ip_exist {vendor library name version} {
    set tempInfo ""
    set tempInfo [string trim [ip_catalog_list -vendor $vendor -library $library -name $name -version $version]]
    if {! ([string length $tempInfo] > 20 && [string first "--vlnv:" $tempInfo] >0)} {
        puts "Missing IP $vendor:$library:$name:$version"
        return 1
    }
    return 0
}

set ipVersionDict [dict create]
set ipVlnvDict [dict create]
set missing_ip 0

dict set ipVlnvDict "uart0" "latticesemi.com:ip:uart:1.5.0"
dict set ipVlnvDict "apb0" "latticesemi.com:module:apb_interconnect:1.4.0"
dict set ipVlnvDict "ahbl2apb0" "latticesemi.com:module:ahb_lite_to_apb_bridge:1.2.0"
dict set ipVlnvDict "gpio0" "latticesemi.com:ip:gpio:1.8.0"
dict set ipVlnvDict "seg70" "JVos:ip:Seg7:2.0.3"
dict set ipVlnvDict "osc0" "latticesemi.com:module:osc:1.1.0"
dict set ipVlnvDict "ahbl0" "latticesemi.com:module:ahb_lite_interconnect:1.5.0"
dict set ipVlnvDict "cpu0" "latticesemi.com:ip:riscv_sm:1.8.0"
dict set ipVlnvDict "system0" "latticesemi.com:ip:system_memory:2.5.1"


dict for {key value} $ipVlnvDict {
    set vlnList [split $value ":"]
    if {[llength $vlnList] == 4} {
        set version [lindex $vlnList 3]
        dict set ipVersionDict "$key" $version
        
        set res [is_ip_exist [lindex $vlnList 0] [lindex $vlnList 1] [lindex $vlnList 2] [lindex $vlnList 3]]
        if {$res == 1} {				
            set missing_ip 1                
        }
    }
}
if {$missing_ip} {
    error "IPs are missing. Cleanup design."
}


sbp_config_ip -vlnv "JVos:ip:seg70:[dict get $ipVersionDict "seg70"]"  -meta_vlnv "JVos:ip:Seg7:[dict get $ipVersionDict "seg70"]" -cfg_value {}
sbp_config_ip -vlnv "latticesemi.com:ip:cpu0:[dict get $ipVersionDict "cpu0"]"  -meta_vlnv "latticesemi.com:ip:riscv_sm:[dict get $ipVersionDict "cpu0"]" -cfg_value {IRQ_NUM: 2,  TIMER_ENABLE: true}
sbp_config_ip -vlnv "latticesemi.com:ip:gpio0:[dict get $ipVersionDict "gpio0"]"  -meta_vlnv "latticesemi.com:ip:gpio:[dict get $ipVersionDict "gpio0"]" -cfg_value {IO_LINES_COUNT: 9,  EXTERNAL_BUF: false,  OUT_RESET_VAL_INPUT: 0,  DIRECTION_DEF_VAL_INPUT: FF,  IF_USER_INTF: APB}
sbp_config_ip -vlnv "latticesemi.com:ip:system0:[dict get $ipVersionDict "system0"]"  -meta_vlnv "latticesemi.com:ip:system_memory:[dict get $ipVersionDict "system0"]" -cfg_value {INTERFACE: AHBL,  ADDR_DEPTH: 8192,  PORT_COUNT: 2,  INIT_MEM: false,  INIT_FILE_IN: ../../XO4_SW2/Debug/XO4_SW2.mem,  REGMODE_S0: true,  REGMODE_S1: true}
sbp_config_ip -vlnv "latticesemi.com:ip:uart0:[dict get $ipVersionDict "uart0"]"  -meta_vlnv "latticesemi.com:ip:uart:[dict get $ipVersionDict "uart0"]" -cfg_value {SYS_CLOCK_FREQ: 29.56}
sbp_config_ip -vlnv "latticesemi.com:module:ahbl0:[dict get $ipVersionDict "ahbl0"]"  -meta_vlnv "latticesemi.com:module:ahb_lite_interconnect:[dict get $ipVersionDict "ahbl0"]" -cfg_value {TOTAL_MASTER_CNT: 1,  TOTAL_SLAVE_CNT: 2}
sbp_config_ip -vlnv "latticesemi.com:module:ahbl2apb0:[dict get $ipVersionDict "ahbl2apb0"]"  -meta_vlnv "latticesemi.com:module:ahb_lite_to_apb_bridge:[dict get $ipVersionDict "ahbl2apb0"]" -cfg_value {APB_CLK_EN: true}
sbp_config_ip -vlnv "latticesemi.com:module:apb0:[dict get $ipVersionDict "apb0"]"  -meta_vlnv "latticesemi.com:module:apb_interconnect:[dict get $ipVersionDict "apb0"]" -cfg_value {TOTAL_MASTER_CNT: 1,  TOTAL_SLAVE_CNT: 3}
sbp_config_ip -vlnv "latticesemi.com:module:osc0:[dict get $ipVersionDict "osc0"]"  -meta_vlnv "latticesemi.com:module:osc:[dict get $ipVersionDict "osc0"]" -cfg_value {NOM_FREQ: 29.56}



sbp_add_component -vlnv "JVos:ip:seg70:[dict get $ipVersionDict "seg70"]" -name seg70_inst
sbp_add_component -vlnv "latticesemi.com:ip:cpu0:[dict get $ipVersionDict "cpu0"]" -name cpu0_inst
sbp_add_component -vlnv "latticesemi.com:ip:gpio0:[dict get $ipVersionDict "gpio0"]" -name gpio0_inst
sbp_add_component -vlnv "latticesemi.com:ip:system0:[dict get $ipVersionDict "system0"]" -name system0_inst
sbp_add_component -vlnv "latticesemi.com:ip:uart0:[dict get $ipVersionDict "uart0"]" -name uart0_inst
sbp_add_component -vlnv "latticesemi.com:module:ahbl0:[dict get $ipVersionDict "ahbl0"]" -name ahbl0_inst
sbp_add_component -vlnv "latticesemi.com:module:ahbl2apb0:[dict get $ipVersionDict "ahbl2apb0"]" -name ahbl2apb0_inst
sbp_add_component -vlnv "latticesemi.com:module:apb0:[dict get $ipVersionDict "apb0"]" -name apb0_inst
sbp_add_component -vlnv "latticesemi.com:module:osc0:[dict get $ipVersionDict "osc0"]" -name osc0_inst


sbp_add_port -direction in rstn_i
sbp_add_port -direction in uart_rxd_00_i
sbp_add_port -direction out uart_txd_00_o
sbp_add_port -from 8 -to 0 -direction inout gpio_00_io
sbp_add_port -from 7 -to 0 -direction out seg7_out

sbp_connect_net "$projectName/cpu0_inst/rst_n_i" "$projectName/rstn_i" 
sbp_connect_net "$projectName/cpu0_inst/system_resetn_o" "$projectName/ahbl0_inst/ahbl_hresetn_i" "$projectName/ahbl2apb0_inst/presetn_i" "$projectName/ahbl2apb0_inst/rst_n_i" "$projectName/gpio0_inst/resetn_i" "$projectName/apb0_inst/apb_presetn_i" "$projectName/uart0_inst/rst_n_i" "$projectName/seg70_inst/RST_N" "$projectName/system0_inst/ahbl_hresetn_i" 
sbp_connect_net "$projectName/ahbl2apb0_inst/clk_i" "$projectName/ahbl2apb0_inst/pclk_i" "$projectName/ahbl0_inst/ahbl_hclk_i" "$projectName/cpu0_inst/clk_i" "$projectName/gpio0_inst/clk_i" "$projectName/apb0_inst/apb_pclk_i" "$projectName/osc0_inst/clk_out_o" "$projectName/uart0_inst/clk_i" "$projectName/seg70_inst/PCLK" "$projectName/system0_inst/ahbl_hclk_i" 
sbp_connect_net "$projectName/uart0_inst/rxd_i" "$projectName/uart_rxd_00_i" 
sbp_connect_net "$projectName/uart0_inst/txd_o" "$projectName/uart_txd_00_o" 
sbp_connect_net "$projectName/gpio0_inst/gpio_io" "$projectName/gpio_00_io" 
sbp_connect_net "$projectName/seg70_inst/SEG7_OUT" "$projectName/seg7_out" 

sbp_connect_interface_net "$projectName/ahbl0_inst/AHBL_M00" "$projectName/system0_inst/AHBL_S1" 
sbp_connect_interface_net "$projectName/ahbl0_inst/AHBL_M01" "$projectName/ahbl2apb0_inst/AHBL_S0" 
sbp_connect_interface_net "$projectName/ahbl2apb0_inst/APB_M0" "$projectName/apb0_inst/APB_S00" 
sbp_connect_interface_net "$projectName/apb0_inst/APB_M00" "$projectName/uart0_inst/APB_S0" 
sbp_connect_interface_net "$projectName/apb0_inst/APB_M01" "$projectName/gpio0_inst/APB_S0" 
sbp_connect_interface_net "$projectName/apb0_inst/APB_M02" "$projectName/seg70_inst/APB_S0" 
sbp_connect_interface_net "$projectName/cpu0_inst/AHBL_M0_INSTR" "$projectName/system0_inst/AHBL_S0" 
sbp_connect_interface_net "$projectName/cpu0_inst/AHBL_M1_DATA" "$projectName/ahbl0_inst/AHBL_S00" 
sbp_connect_interface_net "$projectName/gpio0_inst/INTR" "$projectName/cpu0_inst/IRQ_S0" 
sbp_connect_interface_net "$projectName/uart0_inst/INT_M0" "$projectName/cpu0_inst/IRQ_S1" 




sbp_connect_constant -constant 1'B0 "$projectName/osc0_inst/stdby_i"

sbp_assign_addr_seg -offset 'h0000A800 "$projectName/apb0_inst/APB_M02" "$projectName/seg70_inst/APB_S0"
sbp_assign_addr_seg -offset 'h0000A000 "$projectName/apb0_inst/APB_M01" "$projectName/gpio0_inst/APB_S0"
sbp_assign_addr_seg -offset 'h00000000 "$projectName/cpu0_inst/AHBL_M0_INSTR" "$projectName/system0_inst/AHBL_S0"
sbp_assign_addr_seg -offset 'h00000000 "$projectName/ahbl0_inst/AHBL_M00" "$projectName/system0_inst/AHBL_S1"
sbp_assign_addr_seg -offset 'h0000B000 "$projectName/apb0_inst/APB_M00" "$projectName/uart0_inst/APB_S0"

 
sbp_design set_strategy -name par_place_iterator -value {10}
sbp_design set_strategy -name par_stop_zero -value {True}

sbp_design save
sbp_design generate
    
} on error {msg options} {

sbp_design close
set oldProPath [string cat $targetDir "/" $projectName]
if {[file exists [string cat $oldProPath "/.socproject"]] == 1} {
    if {[file exists [string cat $oldProPath ".failed"]] == 1} {
        file delete -force [string cat $oldProPath ".failed"]
    }
    file rename -force $oldProPath [string cat $oldProPath ".failed"]
}
set errorMsg [string cat $::errorInfo "\n" $msg "\n" ]
error $errorMsg
}


sbp_design close

try {
set verificationName  "${projectName}_v"

sbp_design open -name "$verificationName" -path "$targetDir/$projectName/verification/$verificationName.sbx"
sbp_replace -vlnv {lattice:systembuilder:dut:1.0} -name {dut_inst} -component "$verificationName/dut_inst"

sbp_design save

sbp_config_ip -vlnv {latticesemi.com:sim_model:sysclk_rst_gen1:1.0.0}  -meta_vlnv {latticesemi.com:sim_model:Clock_Reset_Generator:1.0.0} -cfg_value {DUT_CLK_IN_EN: 1,  DUT_RST_IN_EN: 1,  TB_CLK_PERIOD: 55,  TB_RST_PERIOD: 500}
sbp_config_ip -vlnv {latticesemi.com:sim_model:uart_model1:1.0.0}  -meta_vlnv {latticesemi.com:sim_model:UART_Model:1.0.0} -cfg_value {CLK_MHZ: 18,  DEBUG_PINS_EN: false}


sbp_add_component -vlnv "latticesemi.com:sim_model:sysclk_rst_gen1:1.0.0" -name sysclk_rst_gen1_inst
sbp_add_component -vlnv "latticesemi.com:sim_model:uart_model1:1.0.0" -name uart_model1_inst




sbp_connect_net "$verificationName/dut_inst/uart_txd_00_o" "$verificationName/uart_model1_inst/uart_rxd" 
sbp_connect_net "$verificationName/sysclk_rst_gen1_inst/tb_clk_o" "$verificationName/uart_model1_inst/clk" 
sbp_connect_net "$verificationName/sysclk_rst_gen1_inst/tb_rst_o" "$verificationName/uart_model1_inst/rstn" "$verificationName/dut_inst/rstn_i" 
sbp_connect_net "$verificationName/uart_model1_inst/uart_txd" "$verificationName/dut_inst/uart_rxd_00_i" 




sbp_connect_constant -constant 1'B1 "$verificationName/sysclk_rst_gen1_inst/dut_rst_i"


sbp_design save
    
} on error {msg options} {

sbp_design close
set oldProPath [string cat $targetDir "/" $projectName]
if {[file exists [string cat $oldProPath "/.socproject"]] == 1} {
    if {[file exists [string cat $oldProPath ".failed"]] == 1} {
        file delete -force [string cat $oldProPath ".failed"]
    }
    file rename -force $oldProPath [string cat $oldProPath ".failed"]
}
set errorMsg [string cat $::errorInfo "\n" $msg "\n" ]
error $errorMsg
}

sbp_design close
try {
    file copy -force "C:/workspace/MachXO4_Lab2/XO4_HW2/XO4_HW2/lib/IPs" "$targetDir/$projectName/$projectName/lib/IPs"
    file copy -force "C:/workspace/MachXO4_Lab2/XO4_HW2/XO4_HW2/XO4_HW2.layout" "$targetDir/$projectName/$projectName/$projectName.layout"
