-L work
-reflib pmi_work
-reflib ovi_lfmxo4


"C:/workspace/MachXO4_Lab2/SEG7/source/impl_1/seg7_base.v" 
"C:/workspace/MachXO4_Lab2/SEG7/source/impl_1/abp_seg7.v" 
-optionset VOPTDEBUG
+noacc+pmi_work.*
+noacc+ovi_lfmxo4.*

-vopt.options
  -suppress vopt-7033
-end

-gui
-top apb_slave
-vsim.options
  -suppress vsim-7033,vsim-8630,3009,3389
  -t ns
-end

-do "view wave"
-do "add wave /*"
-do "run 100 ns"
