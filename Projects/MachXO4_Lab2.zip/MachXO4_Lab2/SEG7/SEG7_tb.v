
`timescale 1ns / 1ps
module abp_slave_tb ();

// Inputs
	reg PCLK;
	reg RST_N;
	reg [2:0] PADDR;
	reg PSEL;
	reg PENABLE;
	reg PWRITE;
	reg [31:0] PWDATA;


// Outputs
	wire [31:0] PRDATA;
	wire PREADY;
	wire PSLVERR;
	wire [6:0] SEG7_OUT;
	wire SEG_DP;


// Bidirs


// Instantiate the UUT
	apb_slave UUT (
		.PCLK(PCLK), 
		.RST_N(RST_N), 
		.PADDR(PADDR), 
		.PSEL(PSEL), 
		.PENABLE(PENABLE), 
		.PWRITE(PWRITE), 
		.PWDATA(PWDATA), 
		.PRDATA(PRDATA), 
		.PREADY(PREADY), 
		.PSLVERR(PSLVERR), 
		.SEG7_OUT(SEG7_OUT), 
		.SEG_DP(SEG_DP)
	);


// Initialize Inputs

// generate the clock
	initial begin
		PCLK = 1'b0;
		forever #1 PCLK = ~PCLK;
	end

// Generate the reset
	initial begin
		RST_N = 1'b1;
		#10
		RST_N = 1'b0;
	end

	initial begin
		PADDR = 0;
		PSEL = 0;
		PENABLE = 0;
		PWRITE = 0;
		PWDATA = 0;
		#20
	
		PADDR = 0;
		PWRITE = 0;
		PSEL = 1;
		PENABLE = 0;
		#2
		PENABLE= 1;
		#10
	
	end
	
endmodule : abp_slave_tb