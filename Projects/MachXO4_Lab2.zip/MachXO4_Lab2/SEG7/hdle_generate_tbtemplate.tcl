lappend auto_path "C:/lscc/radiant/2025.2/scripts/tcl/simulation"
package require tbtemplate_generation

set ::bali::Para(MODNAME) apb_slave
set ::bali::Para(PROJECT) SEG7
set ::bali::Para(PRIMITIVEFILE) {"C:/lscc/radiant/2025.2/cae_library/synthesis/verilog/lfmxo4.v=lfmxo4"}
set ::bali::Para(TFT) {"C:/lscc/radiant/2025.2/data/templates/plsitft_xo2c00.tft"}
set ::bali::Para(OUTNAME) apb_slave_tf
set ::bali::Para(EXT) .v
set ::bali::Para(FILELIST) {"C:/workspace/MachXO4_Lab2/SEG7/source/impl_1/seg7_base.v=work,Verilog,Verilog_2001" "C:/workspace/MachXO4_Lab2/SEG7/source/impl_1/abp_seg7.v=work,Verilog,Verilog_2001" }
set ::bali::Para(INCLUDEPATH) {"C:/workspace/MachXO4_Lab2/SEG7/source/impl_1" }
::bali::GenerateTbTemplate
