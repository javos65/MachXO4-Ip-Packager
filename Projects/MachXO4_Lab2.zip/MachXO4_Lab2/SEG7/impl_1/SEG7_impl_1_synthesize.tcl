if {[catch {

# define run engine funtion
source [file join {C:/lscc/radiant/2025.2} scripts tcl flow run_engine.tcl]
# define global variables
global para
set para(gui_mode) "1"
set para(prj_dir) "C:/workspace/MachXO4_Lab2/SEG7"
if {![file exists {C:/workspace/MachXO4_Lab2/SEG7/impl_1}]} {
  file mkdir {C:/workspace/MachXO4_Lab2/SEG7/impl_1}
}
cd {C:/workspace/MachXO4_Lab2/SEG7/impl_1}
# synthesize IPs
# synthesize VMs
# synthesize top design
file delete -force -- SEG7_impl_1.vm SEG7_impl_1.ldc
if {[file normalize "C:/workspace/MachXO4_Lab2/SEG7/impl_1/SEG7_impl_1_synplify.tcl"] != [file normalize "./SEG7_impl_1_synplify.tcl"]} {
  file copy -force "C:/workspace/MachXO4_Lab2/SEG7/impl_1/SEG7_impl_1_synplify.tcl" "./SEG7_impl_1_synplify.tcl"
}
if {[ catch {::radiant::runengine::run_engine synpwrap -prj "SEG7_impl_1_synplify.tcl" -log "SEG7_impl_1.srf"} result options ]} {
    file delete -force -- SEG7_impl_1.vm SEG7_impl_1.ldc
    return -options $options $result
}
::radiant::runengine::run_postsyn [list -a LFMXO4 -p LFMXO4D-110HC -t BBG484 -sp 5 -oc Commercial -top -w -o SEG7_impl_1_syn.udb SEG7_impl_1.vm] [list SEG7_impl_1.ldc]

} out]} {
   ::radiant::runengine::runtime_log $out
   exit 1
}
