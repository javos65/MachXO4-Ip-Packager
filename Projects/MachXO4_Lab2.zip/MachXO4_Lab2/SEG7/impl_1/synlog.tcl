run_tcl -fg SEG7_impl_1_synplify.tcl
