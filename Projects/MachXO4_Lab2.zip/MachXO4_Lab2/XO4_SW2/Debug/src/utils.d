src/utils.o: ../src/utils.c ../src/utils.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/sys_platform.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/riscv_errors.h \
 ../src/platform_init.h
../src/utils.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/sys_platform.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/riscv_errors.h:
../src/platform_init.h:
