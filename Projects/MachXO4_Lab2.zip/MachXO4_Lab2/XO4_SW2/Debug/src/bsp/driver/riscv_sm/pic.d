src/bsp/driver/riscv_sm/pic.o: ../src/bsp/driver/riscv_sm/pic.c \
 ../src/bsp/driver/riscv_sm/pic.h ../src/bsp/driver/riscv_sm/util.h \
 ../src/bsp/driver/riscv_sm/stack.h \
 ../src/bsp/driver/riscv_sm/reg_access.h
../src/bsp/driver/riscv_sm/pic.h:
../src/bsp/driver/riscv_sm/util.h:
../src/bsp/driver/riscv_sm/stack.h:
../src/bsp/driver/riscv_sm/reg_access.h:
