src/bsp/driver/riscv_sm/util.o: ../src/bsp/driver/riscv_sm/util.c \
 ../src/bsp/driver/riscv_sm/util.h ../src/bsp/driver/riscv_sm/stack.h
../src/bsp/driver/riscv_sm/util.h:
../src/bsp/driver/riscv_sm/stack.h:
