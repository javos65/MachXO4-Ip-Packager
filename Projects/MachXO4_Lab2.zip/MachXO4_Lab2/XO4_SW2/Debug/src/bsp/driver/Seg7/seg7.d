src/bsp/driver/Seg7/seg7.o: ../src/bsp/driver/Seg7/seg7.c \
 ../src/bsp/driver/Seg7/seg7.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/reg_access.h
../src/bsp/driver/Seg7/seg7.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/reg_access.h:
