src/bsp/driver/uart/uart.o: ../src/bsp/driver/uart/uart.c \
 ../src/bsp/driver/uart/uart.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/hal.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/pic.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/util.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/stack.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/reg_access.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/iob.h
../src/bsp/driver/uart/uart.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/hal.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/pic.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/util.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/stack.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/reg_access.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/iob.h:
