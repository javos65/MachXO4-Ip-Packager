src/bsp/driver/riscv_sm/interrupt.o: \
 ../src/bsp/driver/riscv_sm/interrupt.c ../src/bsp/driver/riscv_sm/pic.h \
 ../src/bsp/driver/riscv_sm/util.h ../src/bsp/driver/riscv_sm/stack.h \
 ../src/bsp/driver/riscv_sm/interrupt.h
../src/bsp/driver/riscv_sm/pic.h:
../src/bsp/driver/riscv_sm/util.h:
../src/bsp/driver/riscv_sm/stack.h:
../src/bsp/driver/riscv_sm/interrupt.h:
