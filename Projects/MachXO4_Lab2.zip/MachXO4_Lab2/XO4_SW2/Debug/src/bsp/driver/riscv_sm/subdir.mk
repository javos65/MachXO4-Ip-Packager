################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/bsp/driver/riscv_sm/exit.c \
../src/bsp/driver/riscv_sm/interrupt.c \
../src/bsp/driver/riscv_sm/iob.c \
../src/bsp/driver/riscv_sm/pic.c \
../src/bsp/driver/riscv_sm/reg_access.c \
../src/bsp/driver/riscv_sm/timer.c \
../src/bsp/driver/riscv_sm/util.c 

S_UPPER_SRCS += \
../src/bsp/driver/riscv_sm/crt0.S 

OBJS += \
./src/bsp/driver/riscv_sm/crt0.o \
./src/bsp/driver/riscv_sm/exit.o \
./src/bsp/driver/riscv_sm/interrupt.o \
./src/bsp/driver/riscv_sm/iob.o \
./src/bsp/driver/riscv_sm/pic.o \
./src/bsp/driver/riscv_sm/reg_access.o \
./src/bsp/driver/riscv_sm/timer.o \
./src/bsp/driver/riscv_sm/util.o 

S_UPPER_DEPS += \
./src/bsp/driver/riscv_sm/crt0.d 

C_DEPS += \
./src/bsp/driver/riscv_sm/exit.d \
./src/bsp/driver/riscv_sm/interrupt.d \
./src/bsp/driver/riscv_sm/iob.d \
./src/bsp/driver/riscv_sm/pic.d \
./src/bsp/driver/riscv_sm/reg_access.d \
./src/bsp/driver/riscv_sm/timer.d \
./src/bsp/driver/riscv_sm/util.d 


# Each subdirectory must supply rules for building sources it contributes
src/bsp/driver/riscv_sm/%.o: ../src/bsp/driver/riscv_sm/%.S src/bsp/driver/riscv_sm/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GNU RISC-V Cross Assembler'
	riscv-none-embed-gcc -march=rv32i -mabi=ilp32 -msmall-data-limit=8 -mno-save-restore -O0 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -Wframe-larger-than=2560  -g3 -x assembler-with-cpp -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '

src/bsp/driver/riscv_sm/%.o: ../src/bsp/driver/riscv_sm/%.c src/bsp/driver/riscv_sm/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GNU RISC-V Cross C Compiler'
	riscv-none-embed-gcc -march=rv32i -mabi=ilp32 -msmall-data-limit=8 -mno-save-restore -O0 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -Wframe-larger-than=2560  -g3 -DLSCC_STDIO_UART_APB -I"C:\workspace\MachXO4_Lab2\XO4_SW2/src" -I"C:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp" -I"C:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver" -I"C:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/Seg7" -I"C:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/gpio" -I"C:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm" -I"C:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/uart" -std=gnu11 --specs=picolibc.specs -DPICOLIBC_INTEGER_PRINTF_SCANF -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


