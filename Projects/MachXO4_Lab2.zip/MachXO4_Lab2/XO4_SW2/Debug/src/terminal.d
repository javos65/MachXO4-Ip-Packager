src/terminal.o: ../src/terminal.c ../src/terminal.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/hal.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/pic.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/util.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/stack.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/reg_access.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/iob.h \
 ../src/platform_init.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/sys_platform.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/riscv_errors.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/uart/uart.h
../src/terminal.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/hal.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/pic.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/util.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/stack.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/reg_access.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/iob.h:
../src/platform_init.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/sys_platform.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/riscv_errors.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/uart/uart.h:
