src/main.o: ../src/main.c \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/hal.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/pic.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/util.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/stack.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/reg_access.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/iob.h \
 ../src/utils.h C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/sys_platform.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/riscv_errors.h \
 ../src/platform_init.h ../src/device_info.h ../src/terminal.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/uart/uart.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/Seg7/seg7.h \
 C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/gpio/gpio.h
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/hal.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/pic.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/util.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/stack.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/reg_access.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/riscv_sm/iob.h:
../src/utils.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/sys_platform.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/riscv_errors.h:
../src/platform_init.h:
../src/device_info.h:
../src/terminal.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/uart/uart.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/Seg7/seg7.h:
C\:\workspace\MachXO4_Lab2\XO4_SW2/src/bsp/driver/gpio/gpio.h:
