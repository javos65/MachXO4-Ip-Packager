set current_path "C:/workspace/MachXO4_Lab2/XO4_HW2"

cd $current_path

set radiant_project "C:/workspace/MachXO4_Lab2/XO4_HW2/XO4_HW2.rdf"

set DEVICE "LFMXO4-110HC-5BBG484C"

set DESIGN "XO4_HW2"

array set VFILE_LIST ""
set VFILE_LIST(1) "C:/workspace/MachXO4_Lab2/XO4_HW2/XO4_HW2/lib/latticesemi.com/ip/uart0/1.5.0/uart0.ipx"
set VFILE_LIST(2) "C:/workspace/MachXO4_Lab2/XO4_HW2/XO4_HW2/lib/JVos/ip/seg70/2.0.1/seg70.ipx"
set VFILE_LIST(3) "C:/workspace/MachXO4_Lab2/XO4_HW2/XO4_HW2/XO4_HW2.v"
set VFILE_LIST(4) "C:/workspace/MachXO4_Lab2/XO4_HW2/XO4_HW2/lib/latticesemi.com/ip/system0/2.5.1/system0.ipx"
set VFILE_LIST(5) "C:/workspace/MachXO4_Lab2/XO4_HW2/XO4_HW2/lib/latticesemi.com/module/osc0/1.1.0/osc0.ipx"
set VFILE_LIST(6) "C:/workspace/MachXO4_Lab2/XO4_HW2/XO4_HW2/lib/latticesemi.com/module/ahbl2apb0/1.2.0/ahbl2apb0.ipx"
set VFILE_LIST(7) "C:/workspace/MachXO4_Lab2/XO4_HW2/XO4_HW2/lib/latticesemi.com/module/apb0/1.4.0/apb0.ipx"
set VFILE_LIST(8) "C:/workspace/MachXO4_Lab2/XO4_HW2/XO4_HW2/lib/latticesemi.com/module/ahbl0/1.5.0/ahbl0.ipx"
set VFILE_LIST(9) "C:/workspace/MachXO4_Lab2/XO4_HW2/XO4_HW2/lib/latticesemi.com/ip/gpio0/1.8.0/gpio0.ipx"
set VFILE_LIST(10) "C:/workspace/MachXO4_Lab2/XO4_HW2/XO4_HW2/lib/latticesemi.com/ip/cpu0/1.8.0/cpu0.ipx"

set index [array names VFILE_LIST]
if { [file exists $radiant_project] == 1} {
    prj_open $radiant_project
    prj_set_device -part $DEVICE -performance 5
} else {
    prj_create -name "XO4_HW2" -impl "impl_1" -dev $DEVICE -performance 5 -synthesis "synplify"
    prj_save
}


foreach i $index {
    if { [catch {prj_add_source $VFILE_LIST($i)} fid] } {
        puts "file already exists in project."
    }
}

prj_save

