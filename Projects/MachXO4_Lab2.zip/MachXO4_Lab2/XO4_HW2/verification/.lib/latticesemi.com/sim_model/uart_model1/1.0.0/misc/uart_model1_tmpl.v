    uart_model1 __(.clk( ),
        .rstn( ),
        .uart_rxd( ),
        .uart_txd( ));
