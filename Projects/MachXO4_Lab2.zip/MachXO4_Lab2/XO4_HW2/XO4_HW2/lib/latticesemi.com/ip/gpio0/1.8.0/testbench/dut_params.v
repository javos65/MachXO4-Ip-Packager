localparam FAMILY = "LFMXO4";
localparam IO_LINES_COUNT = 9;
localparam EXTERNAL_BUF = 0;
localparam OUT_RESET_VAL = "32'h00000000";
localparam DIRECTION_DEF_VAL = "32'h000000FF";
localparam IF_USER_INTF = "APB";
`define xo4f00
`define LFMXO4
`define LFMXO4_110HC
