localparam ADDR_WIDTH = 32;
localparam DATA_WIDTH = 32;
localparam APB_CLK_EN = 1;
localparam FAMILY = "LFMXO4";
`define xo4f00
`define LFMXO4
`define LFMXO4_110HC
