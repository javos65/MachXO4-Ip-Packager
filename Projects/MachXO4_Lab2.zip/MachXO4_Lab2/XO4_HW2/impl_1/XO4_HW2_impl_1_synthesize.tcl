if {[catch {

# define run engine funtion
source [file join {C:/lscc/radiant/2025.2} scripts tcl flow run_engine.tcl]
# define global variables
global para
set para(gui_mode) "1"
set para(prj_dir) "C:/workspace/MachXO4_Lab2/XO4_HW2"
if {![file exists {C:/workspace/MachXO4_Lab2/XO4_HW2/impl_1}]} {
  file mkdir {C:/workspace/MachXO4_Lab2/XO4_HW2/impl_1}
}
cd {C:/workspace/MachXO4_Lab2/XO4_HW2/impl_1}
# synthesize IPs
# synthesize VMs
# propgate constraints
file delete -force -- XO4_HW2_impl_1_cpe.ldc
::radiant::runengine::run_engine_newmsg cpe -syn synpro -f "XO4_HW2_impl_1.cprj" "system0.cprj" "gpio0.cprj" "cpu0.cprj" "ahbl2apb0.cprj" "ahbl0.cprj" "uart0.cprj" "apb0.cprj" "osc0.cprj" "seg70.cprj" -a "LFMXO4"  -o XO4_HW2_impl_1_cpe.ldc
# synthesize top design
file delete -force -- XO4_HW2_impl_1.vm XO4_HW2_impl_1.ldc
if {[file normalize "C:/workspace/MachXO4_Lab2/XO4_HW2/impl_1/XO4_HW2_impl_1_synplify.tcl"] != [file normalize "./XO4_HW2_impl_1_synplify.tcl"]} {
  file copy -force "C:/workspace/MachXO4_Lab2/XO4_HW2/impl_1/XO4_HW2_impl_1_synplify.tcl" "./XO4_HW2_impl_1_synplify.tcl"
}
if {[ catch {::radiant::runengine::run_engine synpwrap -prj "XO4_HW2_impl_1_synplify.tcl" -log "XO4_HW2_impl_1.srf"} result options ]} {
    file delete -force -- XO4_HW2_impl_1.vm XO4_HW2_impl_1.ldc
    return -options $options $result
}
::radiant::runengine::run_postsyn [list -a LFMXO4 -p LFMXO4-110HC -t BBG484 -sp 5 -oc Commercial -top -w -o XO4_HW2_impl_1_syn.udb XO4_HW2_impl_1.vm] [list XO4_HW2_impl_1.ldc]

} out]} {
   ::radiant::runengine::runtime_log $out
   exit 1
}
