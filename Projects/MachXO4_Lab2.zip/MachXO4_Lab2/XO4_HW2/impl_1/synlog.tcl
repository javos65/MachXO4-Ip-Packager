run_tcl -fg XO4_HW2_impl_1_synplify.tcl
